package tdtu.finalproject.appsale;

public class Server {
    public static String localhost = "androidn4.000webhostapp.com";
    public static String linkgettype = "http://" + localhost + "/server/gettype.php";
    public static String linkgetitem = "http://" + localhost + "/server/showitem.php";
    public static String linkgetphone = "http://" + localhost + "/server/getlistphone.php";
    public static String linkgetlaptop = "http://" + localhost + "/server/getlistlaptop.php";
    public static String linkgetotheritem = "http://" + localhost + "/server/getlistotheritem.php";
    public static String linkInforCustom = "http://" + localhost + "/server/insertCustom.php";
    public static String linkSendCart = "http://" + localhost + "/server/orderData.php";

}
